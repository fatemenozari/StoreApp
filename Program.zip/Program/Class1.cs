﻿namespace Program;

public class Class1
{
}