﻿namespace Main;

public class Class1
{
}