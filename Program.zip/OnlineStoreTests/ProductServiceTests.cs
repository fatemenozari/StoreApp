using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.Extensions.Logging;
using Moq;
using OnlineStore.Core.Entities;
using OnlineStore.Core.Interfaces;
using OnlineStore.Data.DbContext;
using OnlineStore.Services;
using Moq.EntityFrameworkCore;
namespace OnlineStoreTests;

public class ProductServiceTests
{
    private readonly Mock<ApplicationDbContext> _mockContext;
    private readonly Mock<IDiscountStrategy> _mockDiscountStrategy;
    private readonly Mock<IProductDecorator> _mockProductDecorator;
    private readonly ProductService _productService;
    private readonly Mock<ILogger<ProductService>> _mockLogger;

    public ProductServiceTests()
    {
        _mockContext = new Mock<ApplicationDbContext>();
        _mockDiscountStrategy = new Mock<IDiscountStrategy>();
        _mockProductDecorator = new Mock<IProductDecorator>();
        _mockLogger = new Mock<ILogger<ProductService>>();

        _productService = new ProductService(
            _mockContext.Object, 
            _mockDiscountStrategy.Object, 
            _mockProductDecorator.Object,
            _mockLogger.Object);  
    }


    [Fact]
    public async Task GetProductsAsync_ShouldReturnProducts_WhenProductsExist()
    {
        // Arrange
        var products = new List<Product>
        {
            new Product { Id = 1, Price = 100, Stock = 10, Category = new Category { Name = "Mobile" }},
            new Product { Id = 2, Price = 200, Stock = 5, Category = new Category { Name = "Laptop" }}
        };

        _mockContext.Setup(c => c.Products).ReturnsDbSet(products);

        // Act
        var result = await _productService.GetProductsAsync();

        // Assert
        Assert.NotEmpty(result.Items);
        Assert.Equal(2, result.Items.Count());
    }
    [Fact]
    public async Task GetProductByIdAsync_ShouldReturnProduct_WhenProductExists()
    {
        // Arrange
        var product = new Product { Id = 1, Price = 100, Stock = 10, Category = new Category { Name = "Mobile" }};
        _mockContext.Setup(c => c.Products.FindAsync(1)).ReturnsAsync(product);

        // Act
        var result = await _productService.GetProductByIdAsync(1);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(1, result?.Id);
    }
    [Fact]
    public async Task GetProductsAsync_ShouldApplyDiscount_WhenConditionsMet()
    {
        // Arrange
        var products = new List<Product>
        {
            new() { Id = 1, Price = 100, Stock = 10, Category = new Category { Name = "Mobile" }},
            new() { Id = 2, Price = 200, Stock = 5, Category = new Category { Name = "Laptop" }}
        };

        _mockContext.Setup(c => c.Products).ReturnsDbSet(products);

        _mockDiscountStrategy.Setup(ds => ds.ApplyDiscount(It.IsAny<Product>()))
            .Returns<Product>(product => product.Price * 0.9m);  
        
        // Act
        var result = await _productService.GetProductsAsync();

        // Assert
        Assert.Equal(90, result.Items.First(p => p.Id == 1).Price); 
        Assert.Equal(200, result.Items.First(p => p.Id == 2).Price); 
    }

    [Fact]
    public async Task GetProductsAsync_ShouldDecorateProduct_WhenConditionsMet()
    {
        // Arrange
        var products = new List<Product>
        {
            new() { Id = 1, Price = 100, Stock = 10, Category = new Category { Name = "Mobile" }},
            new() { Id = 2, Price = 200, Stock = 5, Category = new Category { Name = "Laptop" }}
        };

        _mockContext.Setup(c => c.Products).ReturnsDbSet(products);

        _mockProductDecorator.Setup(pd => pd.Decorate(It.IsAny<Product>(), It.IsAny<decimal>()))
            .Callback<Product, decimal>((product, originalPrice) => 
            {
                product.Description += $" - Discount Applied: Original Price {originalPrice}";
            });

        // Act
        var result = await _productService.GetProductsAsync();

        // Assert
        Assert.Contains("Discount Applied: Original Price 100", result.Items.First(p => p.Id == 1).Description);  
        Assert.Contains("Discount Applied: Original Price 200", result.Items.First(p => p.Id == 2).Description);  
    }
    
    [Fact]
    public async Task GetProductsAsync_ShouldApplyDiscountForMobile_WhenStockIsSufficient()
    {
        // Arrange
        var products = new List<Product>
        {
            new Product { Id = 1, Price = 100, Stock = 10, Category = new Category { Name = "Mobile" }},
            new Product { Id = 2, Price = 200, Stock = 5, Category = new Category { Name = "Laptop" }}
        };

        _mockContext.Setup(c => c.Products).ReturnsDbSet(products);
        _mockDiscountStrategy.Setup(ds => ds.ApplyDiscount(It.IsAny<Product>()))
            .Returns<Product>(product => product.Price * 0.9m);  

        // Act
        var result = await _productService.GetProductsAsync();

        // Assert
        Assert.Equal(92.5m, result.Items.First(p => p.Id == 1).Price);  
        Assert.Equal(200m, result.Items.First(p => p.Id == 2).Price); 
    }
    
    [Fact]
    public async Task GetProductsAsync_ShouldNotApplyDiscount_WhenStockIsLessThanTwo()
    {
        // Arrange
        var products = new List<Product>
        {
            new Product { Id = 1, Price = 100, Stock = 1, Category = new Category { Name = "Mobile" }},
            new Product { Id = 2, Price = 200, Stock = 5, Category = new Category { Name = "Mobile" }},
            new Product { Id = 3, Price = 150, Stock = 0, Category = new Category { Name = "Mobile" }}
        };

        _mockContext.Setup(c => c.Products).ReturnsDbSet(products);
        _mockDiscountStrategy.Setup(ds => ds.ApplyDiscount(It.IsAny<Product>()))
            .Returns<Product>(product => product.Price * 0.9m);  
        
        // Act
        var result = await _productService.GetProductsAsync();

        // Assert
        Assert.Equal(100m, result.Items.First(p => p.Id == 1).Price);  // چون موجودی کمتر از 2 است پس نخفیف اعمال نمیشود
        Assert.Equal(200m, result.Items.First(p => p.Id == 2).Price);  //روی این محصول تخفیف اعمال میشود
        Assert.Equal(0m, result.Items.First(p => p.Id == 3).Price);  //موجودی صفر است پس اعمال نباید شود
    }

    [Fact]
    public async Task GetProductsAsync_ShouldReturnPagedResults_WhenPageSizeIsSet()
    {
        // Arrange
        var products = new List<Product>
        {
            new Product { Id = 1, Price = 100, Stock = 10, Category = new Category { Name = "Mobile" }},
            new Product { Id = 2, Price = 200, Stock = 5, Category = new Category { Name = "Mobile" }},
            new Product { Id = 3, Price = 150, Stock = 5, Category = new Category { Name = "Laptop" }},
            new Product { Id = 4, Price = 300, Stock = 3, Category = new Category { Name = "Mobile" }},
            new Product { Id = 5, Price = 400, Stock = 8, Category = new Category { Name = "Laptop" }}
        };

        _mockContext.Setup(c => c.Products).ReturnsDbSet(products);
        _mockDiscountStrategy.Setup(ds => ds.ApplyDiscount(It.IsAny<Product>())).Returns<Product>(product => product.Price * 0.9m);  
        
        // Act
        var result = await _productService.GetProductsAsync(pageIndex: 1, pageSize: 3); 

        // Assert
        Assert.Equal(3, result.Items.Count());  
        Assert.DoesNotContain(result.Items, p => p.Id == 5);
    }
}
