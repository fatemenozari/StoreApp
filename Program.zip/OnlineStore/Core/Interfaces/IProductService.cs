using OnlineStore.Core.Entities;

namespace OnlineStore.Core.Interfaces;

public interface IProductService
{
    Task<PagedResult<Product>> GetProductsAsync(int pageIndex = 1, int pageSize = 10);
    Task<Product> GetProductByIdAsync(int id);
}