using OnlineStore.Core.Entities;

namespace OnlineStore.Core.Interfaces;

public interface IDiscountStrategy
{
    decimal ApplyDiscount(Product price);
}