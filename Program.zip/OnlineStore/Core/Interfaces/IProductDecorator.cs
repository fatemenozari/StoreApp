using OnlineStore.Core.Entities;

namespace OnlineStore.Core.Interfaces;

public interface IProductDecorator
{
    void Decorate(Product product, decimal originalPrice);
}