using OnlineStore.Core.Entities;
using OnlineStore.Data.DbContext;

namespace OnlineStore.Data;

public static class SeedData
{
    public static async Task InitializeAsync(ApplicationDbContext context)
    {
        if (!await context.Products.AnyAsync())
        {
            var products = new List<Product>
            {
                new Product { Name = "iPhone 14", Description = "Latest Apple iPhone", Price = 999.99m, Stock = 10, Discount = 7.5m, CategoryId = 1 },
                new Product { Name = "Samsung Galaxy S22", Description = "Latest Samsung Phone", Price = 799.99m, Stock = 5, Discount = 7.5m, CategoryId = 1 },
                new Product { Name = "Laptop X", Description = "Powerful Laptop", Price = 1200.00m, Stock = 15, CategoryId = 2 }
            };

            await context.Products.AddRangeAsync(products);
            await context.SaveChangesAsync();
        }
    }
}