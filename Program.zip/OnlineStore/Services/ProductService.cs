using OnlineStore.Core.Entities;
using OnlineStore.Core.Interfaces;
using OnlineStore.Data.DbContext;

namespace OnlineStore.Services;

public class ProductService(
    ApplicationDbContext context,
    IDiscountStrategy discountStrategy,
    IProductDecorator productDecorator, ILogger<ProductService> logger)
    : IProductService
{
    public async Task<PagedResult<Product>> GetProductsAsync(int pageIndex = 1, int pageSize = 10)
    {
        var totalCount = await context.Products.CountAsync(p => p.Stock > 0);
        var products = await GetAvailableProductsAsync(pageIndex, pageSize);

        ApplyDiscountAndDecorate(products);

        var sortedProducts = products.OrderBy(p => p.Price).ToList();

        return new PagedResult<Product>(sortedProducts, totalCount, pageIndex, pageSize);
    }



    private async Task<List<Product>> GetAvailableProductsAsync(int pageIndex, int pageSize)
    {
        return await context.Products
            .Where(p => p.Stock > 0) 
            .Skip((pageIndex - 1) * pageSize) 
            .Take(pageSize) 
            .Include(p => p.Category) 
            .ToListAsync();
    }

    private void ApplyDiscountAndDecorate(List<Product> products)
    {
        foreach (var product in products)
        {
            var originalPrice = product.Price;

            if (product.Category.Name == "Mobile" && product.Stock >= 2)
            {
                product.Price = discountStrategy.ApplyDiscount(product);
                var discountPercentage = ((originalPrice - product.Price) / originalPrice) * 100;
                logger.LogInformation(
                    "Discount applied to product {ProductId}: {OriginalPrice} -> {NewPrice} ({DiscountPercentage:F2}%).",
                    product.Id, originalPrice, product.Price, discountPercentage);
            }

            productDecorator.Decorate(product, originalPrice);
        }
    }

    public async Task<Product> GetProductByIdAsync(int id)
    {
        logger.LogInformation("Fetching product with ID: {ProductId}.", id);
        var product = await context.Products.FindAsync(id);

        if (product == null)
            logger.LogWarning("Product with ID {ProductId} not found.", id);

        return product;
    }
}