﻿namespace DependencySetup;

public class Class1
{
}